#pragma once

#include "shape.hpp"

class rectangle : public shape
{
public:
    rectangle() = default;
    ~rectangle() = default;
};
