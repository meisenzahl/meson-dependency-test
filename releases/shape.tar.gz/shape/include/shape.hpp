#pragma once

class shape
{
public:
    shape() = default;
    ~shape() = default;
};
