#pragma once

#include "shape.hpp"

class circle : public shape
{
public:
    circle() = default;
    ~circle() = default;
};
