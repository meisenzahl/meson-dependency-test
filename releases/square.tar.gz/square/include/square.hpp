#pragma once

#include "rectangle.hpp"

class square : public rectangle
{
public:
    square() = default;
    ~square() = default;
};
